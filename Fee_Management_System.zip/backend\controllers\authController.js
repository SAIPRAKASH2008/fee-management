const dataStore = require('../models/dataStore');

exports.login = (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ success: false, message: 'Email and password are required.' });
  }

  const user = dataStore.users.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
  if (!user) {
    return res.status(404).json({ success: false, message: 'No account found with this email.' });
  }

  if (user.password !== password) {
    return res.status(401).json({ success: false, message: 'Invalid password. Access denied.' });
  }

  // Record audit log
  dataStore.audit_logs.push({
    log_id: dataStore.audit_logs.length + 1,
    user_id: user.user_id,
    action: `User ${user.name} logged in via REST API`,
    entity: 'Auth',
    timestamp: new Date().toISOString()
  });

  return res.json({
    success: true,
    message: 'Login successful!',
    user: {
      user_id: user.user_id,
      name: user.name,
      email: user.email,
      role: user.role,
      student_id: user.student_id || null
    },
    token: 'jwt_mock_token_' + Buffer.from(user.email).toString('base64')
  });
};

exports.getUsers = (req, res) => {
  const safeUsers = dataStore.users.map(({ password, ...u }) => u);
  res.json({ success: true, count: safeUsers.length, users: safeUsers });
};
