const dataStore = require('../models/dataStore');

exports.getAllPayments = (req, res) => {
  res.json({ success: true, count: dataStore.payments.length, payments: [...dataStore.payments].reverse() });
};

exports.getPaymentsByStudent = (req, res) => {
  const sid = Number(req.params.studentId);
  const studentPayments = dataStore.payments.filter(p => p.student_id === sid);
  res.json({ success: true, count: studentPayments.length, payments: studentPayments });
};

exports.recordPayment = (req, res) => {
  const { student_id, fee_head_id, amount_paid, payment_mode, gateway, transaction_id, recorded_by } = req.body;
  if (!student_id || !fee_head_id || !amount_paid || !payment_mode) {
    return res.status(400).json({ success: false, message: 'Student ID, Fee Head, Amount, and Mode are required.' });
  }

  const pid = dataStore.payments.length + 1;
  const receipt_number = `RCP-2026-${String(pid + 100).padStart(4, '0')}`;
  const payment_date = new Date().toISOString();

  const newPayment = {
    payment_id: pid,
    student_id: Number(student_id),
    fee_head_id: Number(fee_head_id),
    amount_paid: Number(amount_paid),
    payment_mode,
    gateway: gateway || (payment_mode === 'online' ? 'Razorpay' : 'Offline Counter'),
    transaction_id: transaction_id || `TXN${Date.now()}`,
    payment_date,
    status: 'success',
    recorded_by: recorded_by || 'student'
  };

  dataStore.payments.push(newPayment);

  // Auto-generate receipt
  const newReceipt = {
    receipt_id: dataStore.receipts.length + 1,
    payment_id: pid,
    receipt_number,
    generated_at: payment_date
  };
  dataStore.receipts.push(newReceipt);

  res.status(201).json({
    success: true,
    message: 'Payment processed and receipt generated successfully!',
    payment: newPayment,
    receipt: newReceipt
  });
};
