const dataStore = require('../models/dataStore');

exports.getFeeStructures = (req, res) => {
  const { course, semester } = req.query;
  let result = [...dataStore.fee_structures];

  if (course) result = result.filter(f => f.course === course);
  if (semester) result = result.filter(f => f.semester === semester);

  res.json({ success: true, count: result.length, feeStructures: result });
};

exports.getFeeHeadsByStructure = (req, res) => {
  const structId = Number(req.params.id);
  const heads = dataStore.fee_heads.filter(h => h.fee_structure_id === structId);
  res.json({ success: true, count: heads.length, feeHeads: heads });
};

exports.createFeeStructure = (req, res) => {
  const { name, course, semester, total_amount, fee_heads } = req.body;
  if (!name || !course || !semester || !total_amount) {
    return res.status(400).json({ success: false, message: 'All fee structure fields are required.' });
  }

  const newFS = {
    fee_structure_id: dataStore.fee_structures.length + 1,
    name,
    course,
    semester,
    total_amount: Number(total_amount)
  };

  dataStore.fee_structures.push(newFS);

  if (Array.isArray(fee_heads)) {
    fee_heads.forEach(h => {
      dataStore.fee_heads.push({
        fee_head_id: dataStore.fee_heads.length + 1,
        fee_structure_id: newFS.fee_structure_id,
        head_name: h.head_name,
        amount: Number(h.amount),
        due_date: h.due_date || '2026-07-31'
      });
    });
  }

  res.status(201).json({ success: true, message: 'Fee structure created successfully!', feeStructure: newFS });
};
