const dataStore = require('../models/dataStore');

exports.getDashboardStats = (req, res) => {
  const totalCollected = dataStore.payments.reduce((sum, p) => sum + p.amount_paid, 0);
  const totalStudents = dataStore.students.filter(s => s.status === 'active').length;

  res.json({
    success: true,
    stats: {
      totalCollected,
      totalStudents,
      totalTransactions: dataStore.payments.length,
      availableBranches: dataStore.courses.length
    }
  });
};

exports.getAuditLogs = (req, res) => {
  res.json({ success: true, count: dataStore.audit_logs.length, logs: [...dataStore.audit_logs].reverse() });
};
