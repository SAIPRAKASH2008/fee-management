-- =====================================================
-- Fee Management System (FMS) — Database Schema
-- Version: 1.0 (Based on SDD Section 5)
-- Database Engine: MySQL / MariaDB
-- =====================================================

CREATE DATABASE IF NOT EXISTS fee_management_db;
USE fee_management_db;

-- 1. Table: users (Authentication & Roles)
CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin', 'staff', 'student') NOT NULL,
  email VARCHAR(100) UNIQUE NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 2. Table: fee_structures
CREATE TABLE IF NOT EXISTS fee_structures (
  fee_structure_id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  course VARCHAR(50) NOT NULL,
  semester_year VARCHAR(10) NOT NULL,
  total_amount DECIMAL(10, 2) NOT NULL
);

-- 3. Table: fee_heads
CREATE TABLE IF NOT EXISTS fee_heads (
  fee_head_id INT AUTO_INCREMENT PRIMARY KEY,
  fee_structure_id INT NOT NULL,
  head_name VARCHAR(50) NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  due_date DATE NOT NULL,
  FOREIGN KEY (fee_structure_id) REFERENCES fee_structures(fee_structure_id) ON DELETE CASCADE
);

-- 4. Table: students
CREATE TABLE IF NOT EXISTS students (
  student_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  roll_number VARCHAR(20) UNIQUE NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  course VARCHAR(50) NOT NULL,
  semester_year VARCHAR(10) NOT NULL,
  contact_number VARCHAR(15),
  email VARCHAR(100),
  category ENUM('regular', 'scholarship') DEFAULT 'regular',
  fee_structure_id INT NOT NULL,
  status ENUM('active', 'inactive') DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
  FOREIGN KEY (fee_structure_id) REFERENCES fee_structures(fee_structure_id)
);

-- 5. Table: payments
CREATE TABLE IF NOT EXISTS payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  fee_head_id INT NOT NULL,
  amount_paid DECIMAL(10, 2) NOT NULL,
  payment_mode ENUM('online', 'cash', 'cheque', 'dd') NOT NULL,
  gateway VARCHAR(50) NULL,
  transaction_id VARCHAR(100) UNIQUE NULL,
  payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  status ENUM('success', 'pending', 'failed') DEFAULT 'success',
  recorded_by VARCHAR(50) DEFAULT 'student',
  FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
  FOREIGN KEY (fee_head_id) REFERENCES fee_heads(fee_head_id)
);

-- 6. Table: receipts
CREATE TABLE IF NOT EXISTS receipts (
  receipt_id INT AUTO_INCREMENT PRIMARY KEY,
  payment_id INT UNIQUE NOT NULL,
  receipt_number VARCHAR(30) UNIQUE NOT NULL,
  generated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  pdf_path VARCHAR(255) NULL,
  FOREIGN KEY (payment_id) REFERENCES payments(payment_id) ON DELETE CASCADE
);

-- 7. Table: notifications
CREATE TABLE IF NOT EXISTS notifications (
  notification_id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  message TEXT NOT NULL,
  type ENUM('reminder', 'confirmation') NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  sent_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE
);

-- 8. Table: audit_logs
CREATE TABLE IF NOT EXISTS audit_logs (
  log_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  action VARCHAR(255) NOT NULL,
  entity_affected VARCHAR(50) NULL,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL
);

-- =====================================================
-- Seed Admin & Default Users
-- =====================================================
INSERT INTO users (username, email, password_hash, role) VALUES
('saiprakash', 'saiprakash9813@gmail.com', 'Sai@1978', 'admin'),
('staff', 'staff@fms.edu', 'demo123', 'staff'),
('arjun', 'student@fms.edu', 'demo123', 'student')
ON DUPLICATE KEY UPDATE username=username;
