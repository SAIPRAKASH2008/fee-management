const dataStore = require('../models/dataStore');

// GET all students
exports.getAllStudents = (req, res) => {
  const { course, status, search } = req.query;
  let result = [...dataStore.students];

  if (course) result = result.filter(s => s.course === course);
  if (status) result = result.filter(s => s.status === status);
  if (search) {
    const q = search.toLowerCase();
    result = result.filter(s => s.name.toLowerCase().includes(q) || s.roll.toLowerCase().includes(q) || s.course.toLowerCase().includes(q));
  }

  res.json({ success: true, count: result.length, students: result });
};

// GET student by ID
exports.getStudentById = (req, res) => {
  const student = dataStore.students.find(s => s.student_id === Number(req.params.id));
  if (!student) return res.status(404).json({ success: false, message: 'Student not found.' });

  // Calculate dues
  const fs = dataStore.fee_structures.find(f => f.fee_structure_id === student.fee_structure_id);
  const payments = dataStore.payments.filter(p => p.student_id === student.student_id);
  const paid = payments.reduce((sum, p) => sum + p.amount_paid, 0);
  const total = fs ? fs.total_amount : 50000;
  const pending = Math.max(0, total - paid);

  res.json({ success: true, student, financialSummary: { total, paid, pending } });
};

// POST add new student (Admin & Staff permission)
exports.createStudent = (req, res) => {
  const { name, roll, course, semester, contact, email, category, fee_structure_id } = req.body;
  if (!name || !roll || !course || !semester) {
    return res.status(400).json({ success: false, message: 'Name, Roll number, Course, and Semester are required.' });
  }

  const newStudent = {
    student_id: dataStore.students.length + 1,
    name,
    roll,
    course,
    semester,
    contact: contact || '9876543210',
    email: email || `${roll.toLowerCase()}@fms.edu`,
    category: category || 'regular',
    fee_structure_id: Number(fee_structure_id) || 1,
    status: 'active'
  };

  dataStore.students.push(newStudent);
  res.status(201).json({ success: true, message: `Student ${name} successfully registered in ${course} (${semester})!`, student: newStudent });
};

// PUT update student
exports.updateStudent = (req, res) => {
  const idx = dataStore.students.findIndex(s => s.student_id === Number(req.params.id));
  if (idx === -1) return res.status(404).json({ success: false, message: 'Student not found.' });

  dataStore.students[idx] = { ...dataStore.students[idx], ...req.body };
  res.json({ success: true, message: 'Student updated successfully!', student: dataStore.students[idx] });
};
